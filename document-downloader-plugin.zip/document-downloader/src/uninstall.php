<?php
// Silence is golden. Add cleanup if you later store options.
