# File uploader now broken for adding documents
# Set capabilities
